# Power BI modeling & report guide

## Model
- Fact table: `Orders` (transaction grain: one row per order line; sample uses unique transaction IDs).
- Date dimension: `Date`, one row per date, relationship `Date[Date]` → `Orders[order_date]`.
- Optional dimensions: Product (`category`, `sub_category`), Customer (`customer_id`, `segment`), Geography (`region`).

## Date table DAX
```DAX
Date =
ADDCOLUMNS(
    CALENDAR(MIN(Orders[order_date]), MAX(Orders[order_date])),
    "Year", YEAR([Date]),
    "Month Number", MONTH([Date]),
    "Month", FORMAT([Date], "MMM"),
    "Year Month", FORMAT([Date], "YYYY-MM")
)
```
Sort `Date[Month]` by `Date[Month Number]`; sort Year Month chronologically.

## Measures
```DAX
Total Sales = SUM(Orders[sales])
Total Profit = SUM(Orders[profit])
Order Count = DISTINCTCOUNT(Orders[order_id])
Units Sold = SUM(Orders[quantity])
Profit Margin = DIVIDE([Total Profit], [Total Sales], 0)
Average Order Value = DIVIDE([Total Sales], [Order Count], 0)
Sales Previous Year =
    CALCULATE([Total Sales], SAMEPERIODLASTYEAR('Date'[Date]))
YoY Sales Growth =
    DIVIDE([Total Sales] - [Sales Previous Year], [Sales Previous Year], 0)
```

## Pages / visuals
1. Executive overview: KPI cards (Sales, Profit, Order Count, Margin), monthly sales line chart, revenue by region bar chart.
2. Regional analysis: region/state map if geographic fields are available, regional revenue and margin matrix.
3. Product analysis: category/sub-category bar chart, revenue vs profit scatter, category slicers.
4. Customer analysis: segment revenue, orders, AOV, and customer table.

## Validation checklist
- Reconcile sales/profit totals against source data after documented cleaning.
- Verify date table is marked as Date table.
- Test slicers across all report pages.
- Avoid presenting synthetic values as real company results.
