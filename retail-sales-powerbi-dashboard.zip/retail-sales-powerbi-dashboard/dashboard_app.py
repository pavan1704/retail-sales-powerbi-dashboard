import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title="Retail Sales Analytics", layout="wide")
st.title("Retail Sales Analytics Dashboard")
st.caption("Synthetic portfolio dataset • Use Power BI modeling guide for the native PBIX build.")

df = pd.read_csv(Path(__file__).parent / "data" / "superstore_sample.csv", parse_dates=["order_date"])
df = df.drop_duplicates(subset=["order_id"])
df["sales"] = pd.to_numeric(df["sales"], errors="coerce")
df["profit"] = pd.to_numeric(df["profit"], errors="coerce")
df = df.dropna(subset=["order_date", "sales", "profit"])
min_date, max_date = df.order_date.min().date(), df.order_date.max().date()
with st.sidebar:
    st.header("Filters")
    selected_region = st.multiselect("Region", sorted(df.region.unique()), default=sorted(df.region.unique()))
    selected_category = st.multiselect("Category", sorted(df.category.unique()), default=sorted(df.category.unique()))
    date_range = st.date_input("Order date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)
filtered = df[df.region.isin(selected_region) & df.category.isin(selected_category)]
if isinstance(date_range, tuple) and len(date_range) == 2:
    filtered = filtered[(filtered.order_date.dt.date >= date_range[0]) & (filtered.order_date.dt.date <= date_range[1])]
sales, profit = filtered.sales.sum(), filtered.profit.sum()
margin = profit / sales if sales else 0
k1,k2,k3,k4 = st.columns(4)
k1.metric("Total Sales", f"${sales:,.0f}")
k2.metric("Total Profit", f"${profit:,.0f}")
k3.metric("Orders", f"{filtered.order_id.nunique():,}")
k4.metric("Profit Margin", f"{margin:.1%}")
left,right = st.columns(2)
monthly = filtered.assign(month=filtered.order_date.dt.to_period("M").dt.to_timestamp()).groupby("month", as_index=False)[["sales","profit"]].sum()
left.plotly_chart(px.line(monthly, x="month", y="sales", title="Monthly Sales Trend"), use_container_width=True)
region = filtered.groupby("region", as_index=False)[["sales","profit"]].sum().sort_values("sales", ascending=False)
right.plotly_chart(px.bar(region, x="region", y="sales", title="Sales by Region"), use_container_width=True)
bottom1,bottom2 = st.columns(2)
category = filtered.groupby(["category","sub_category"], as_index=False)[["sales","profit"]].sum()
bottom1.plotly_chart(px.bar(category, x="sub_category", y="sales", color="category", title="Sales by Sub-Category"), use_container_width=True)
segment = filtered.groupby("segment", as_index=False)[["sales","profit"]].sum()
bottom2.plotly_chart(px.bar(segment, x="segment", y="sales", title="Sales by Customer Segment"), use_container_width=True)
st.subheader("Filtered transaction data")
st.dataframe(filtered, use_container_width=True)
