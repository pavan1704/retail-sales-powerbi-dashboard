-- Retail Sales Analytics: SQL examples (adapt dialect as needed)
-- Total sales / profit / orders
SELECT
  SUM(sales) AS total_sales,
  SUM(profit) AS total_profit,
  COUNT(DISTINCT order_id) AS order_count,
  SUM(profit) / NULLIF(SUM(sales), 0) AS profit_margin
FROM retail_sales;

-- Regional performance
SELECT region, SUM(sales) AS revenue, SUM(profit) AS profit,
       SUM(profit) / NULLIF(SUM(sales), 0) AS profit_margin
FROM retail_sales
GROUP BY region
ORDER BY revenue DESC;

-- Category / sub-category contribution
SELECT category, sub_category, SUM(sales) AS revenue, SUM(profit) AS profit
FROM retail_sales
GROUP BY category, sub_category
ORDER BY revenue DESC;

-- Monthly trend
SELECT DATE_TRUNC('month', order_date) AS month,
       SUM(sales) AS revenue, SUM(profit) AS profit
FROM retail_sales
GROUP BY 1
ORDER BY 1;

-- Segment performance
SELECT segment, COUNT(DISTINCT order_id) AS orders,
       SUM(sales) AS revenue, SUM(profit) AS profit
FROM retail_sales
GROUP BY segment
ORDER BY revenue DESC;
