# Retail Sales Analytics & BI Dashboard

**Portfolio project | Synthetic dataset | Power BI + SQL**

## Objective
Explore retail revenue, profit, margin, regional performance, category mix, and trends with a Power BI dashboard. Included sample data is synthetic and intended for learning/demo use.

## Files
- `data/superstore_sample.csv` — sample retail transactions with a few intentionally introduced quality issues.
- `sql/data_analysis.sql` — analytical queries and KPI logic.
- `powerbi/modeling_guide.md` — model relationships, calendar table, DAX measures, and suggested report pages.
- `dashboard_app.py` — optional Streamlit dashboard you can run locally as a preview / companion to Power BI.
- `requirements.txt` — dependencies for the preview app.

## Power BI build steps
1. Power BI Desktop → Get Data → Text/CSV → select `data/superstore_sample.csv`.
2. In Power Query, set `order_date` to Date, numeric columns to appropriate numeric types; remove duplicate `order_id` rows and filter or impute missing values transparently.
3. Create a date table using the guide and mark it as the Date table.
4. Create relationships: `Date[Date]` (1) → `Orders[order_date]` (*), single direction.
5. Build the four report pages described in `powerbi/modeling_guide.md`.
6. Save your actual `.pbix` file in `powerbi/`. A PBIX is not pre-generated here because it must be authored in Power BI Desktop.

## Run optional dashboard preview
```bash
python -m pip install -r requirements.txt
streamlit run dashboard_app.py
```

## Important
This is a starter portfolio project, not evidence of completed professional work. Replace synthetic data with a dataset you are licensed to use, validate your calculations, and describe only work you have actually completed.
